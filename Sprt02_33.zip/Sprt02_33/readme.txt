When you open "fontviewer_sprt02_33.swf", you need to install
Flash Player 8 or later. If you have Flash Player 8 or later, you can open the
.swf file! If you don't have Flash Player 8 or later, you must install
Flash Player 8 or Later.
___________________________________________________________
This font is made by SportieTootie Fonts, do not copyright my typefaces.
Sprt 02_33 is a bitmap and pixelated typeface by SportieTootie Fonts
©2021 SportieTootie Fonts., All rights reserved.